[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$RepositoryPath,
    [string]$UnityPath = '',
    [switch]$SkipExternalToolProbes,
    [string]$OutputPath = ''
)

$ErrorActionPreference = 'Stop'
$issues = [System.Collections.Generic.List[object]]::new()
$repositoryBoundaryViolations = [System.Collections.Generic.List[string]]::new()

function Add-Issue {
    param(
        [Parameter(Mandatory = $true)][string]$Code,
        [Parameter(Mandatory = $true)][string]$Message
    )

    $issues.Add([ordered]@{ code = $Code; message = $Message })
}

function Invoke-GitRevParse {
    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][string[]]$Arguments
    )

    try {
        $value = & git -C $Root rev-parse @Arguments 2>$null
        if ($LASTEXITCODE -eq 0) {
            return (($value | Select-Object -First 1) -as [string]).Trim()
        }
    }
    catch {
    }
    return $null
}

function Test-RepositoryExpectedPath {
    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][string]$RelativePath,
        [Parameter(Mandatory = $true)][ValidateSet('Leaf', 'Container')][string]$PathType
    )

    $currentPath = $Root
    $pathSegments = $RelativePath -split '[\\/]'
    foreach ($segment in (@('') + $pathSegments)) {
        if ($segment) {
            $currentPath = Join-Path $currentPath $segment
        }
        $item = Get-Item -LiteralPath $currentPath -Force -ErrorAction SilentlyContinue
        if (-not $item) {
            return $false
        }
        if (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
            if (-not $repositoryBoundaryViolations.Contains($RelativePath)) {
                $repositoryBoundaryViolations.Add($RelativePath)
            }
            return $false
        }
    }

    if ($PathType -eq 'Leaf') {
        return -not $item.PSIsContainer
    }
    return [bool]$item.PSIsContainer
}

function Add-UnityCandidate {
    param(
        [Parameter(Mandatory = $true)][AllowEmptyCollection()][System.Collections.Generic.List[string]]$Candidates,
        [Parameter(Mandatory = $true)][string]$CandidatePath
    )

    $editorPath = $null
    if (Test-Path -LiteralPath $CandidatePath -PathType Leaf) {
        if ([System.IO.Path]::GetFileName($CandidatePath) -ieq 'Unity.exe') {
            $editorPath = [System.IO.Path]::GetFullPath($CandidatePath)
        }
    }
    elseif (Test-Path -LiteralPath $CandidatePath -PathType Container) {
        foreach ($relativePath in @('Editor\Unity.exe', 'Unity.exe')) {
            $possibleEditor = Join-Path $CandidatePath $relativePath
            if (Test-Path -LiteralPath $possibleEditor -PathType Leaf) {
                $editorPath = [System.IO.Path]::GetFullPath($possibleEditor)
                break
            }
        }
    }

    if ($editorPath -and -not $Candidates.Contains($editorPath)) {
        $Candidates.Add($editorPath)
    }
}

function Get-UnityProductVersion {
    param([Parameter(Mandatory = $true)][string]$EditorPath)

    try {
        $productVersion = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($EditorPath).ProductVersion
        if ($productVersion -is [string] -and -not [string]::IsNullOrWhiteSpace($productVersion)) {
            $trimmedProductVersion = $productVersion.Trim()
            if ($trimmedProductVersion -cmatch '^(?<editorVersion>[0-9]+\.[0-9]+\.[0-9]+[abfp][0-9]+)(?:_[0-9a-f]{12})?$') {
                return $Matches.editorVersion
            }
        }
    }
    catch {
    }
    return $null
}

$repositoryRootItem = Get-Item -LiteralPath $RepositoryPath -Force -ErrorAction Stop
if (-not $repositoryRootItem.PSIsContainer) {
    throw "RepositoryPath must resolve to a directory: $RepositoryPath"
}
$resolvedRepository = $repositoryRootItem.FullName
$repositoryRootRejected = ($repositoryRootItem.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0
if ($repositoryRootRejected) {
    $repositoryBoundaryViolations.Add('.')
}

$packageManifestPath = Join-Path $resolvedRepository 'package.json'
$packageName = $null
$packageVersion = $null
$unityLine = $null
$hasPackageManifest = $false
if (-not $repositoryRootRejected) {
    $hasPackageManifest = Test-RepositoryExpectedPath -Root $resolvedRepository -RelativePath 'package.json' -PathType Leaf
}
if ($hasPackageManifest) {
    try {
        $packageManifest = Get-Content -LiteralPath $packageManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($packageManifest.name -isnot [string] -or [string]::IsNullOrWhiteSpace($packageManifest.name) -or
            $packageManifest.version -isnot [string] -or [string]::IsNullOrWhiteSpace($packageManifest.version)) {
            Add-Issue -Code 'APPUI_PACKAGE_MANIFEST_INVALID' -Message 'The root package.json name and version must be non-empty strings.'
        }
        else {
            $packageName = $packageManifest.name
            $packageVersion = $packageManifest.version
        }
        if ($packageManifest.unity -isnot [string] -or $packageManifest.unity -notmatch '^[0-9]+\.[0-9]+$') {
            Add-Issue -Code 'APPUI_UNITY_LINE_INVALID' -Message 'The root package.json unity field must declare the official major.minor line.'
        }
        else {
            $unityLine = $packageManifest.unity
        }
    }
    catch {
        Add-Issue -Code 'APPUI_PACKAGE_MANIFEST_INVALID' -Message 'The root package.json could not be parsed.'
    }
}
else {
    Add-Issue -Code 'APPUI_PACKAGE_MANIFEST_MISSING' -Message 'The repository root does not contain package.json.'
}

$validationProjectVersionRelativePath = 'Validation~\Unity6000.0Consumer\ProjectSettings\ProjectVersion.txt'
$hasValidationProjectVersion = $false
$validationEditorVersion = $null
$validationUnityLine = $null
if (-not $repositoryRootRejected) {
    $hasValidationProjectVersion = Test-RepositoryExpectedPath -Root $resolvedRepository `
        -RelativePath $validationProjectVersionRelativePath -PathType Leaf
}
if ($hasValidationProjectVersion) {
    try {
        $projectVersionText = Get-Content -LiteralPath (Join-Path $resolvedRepository $validationProjectVersionRelativePath) `
            -Raw -Encoding UTF8
        $declaredEditorVersion = $null
        if ($projectVersionText -match '(?m)^m_EditorVersion:\s*([^\s]+)\s*$') {
            $declaredEditorVersion = $Matches[1]
        }
        if ($declaredEditorVersion -and
            $declaredEditorVersion -match '^([0-9]+\.[0-9]+)\.[0-9]+[abfp][0-9]+$') {
            $validationEditorVersion = $declaredEditorVersion
            $validationUnityLine = $Matches[1]
        }
        else {
            Add-Issue -Code 'APPUI_VALIDATION_EDITOR_PIN_INVALID' -Message 'The validation ProjectVersion.txt must contain an exact Unity Editor pin.'
        }
    }
    catch {
        Add-Issue -Code 'APPUI_VALIDATION_EDITOR_PIN_INVALID' -Message 'The validation ProjectVersion.txt could not be parsed.'
    }
}
else {
    Add-Issue -Code 'APPUI_VALIDATION_EDITOR_PIN_MISSING' -Message 'The validation ProjectVersion.txt exact Editor pin is missing.'
}
if ($unityLine -and $validationUnityLine -and $unityLine -cne $validationUnityLine) {
    Add-Issue -Code 'APPUI_UNITY_DECLARATION_MISMATCH' -Message 'The package unity line does not match the validation Editor pin.'
}

$gitRoot = $null
$branch = $null
$isWorktree = $false
if (-not $repositoryRootRejected) {
    $gitRoot = Invoke-GitRevParse -Root $resolvedRepository -Arguments @('--show-toplevel')
    $branch = Invoke-GitRevParse -Root $resolvedRepository -Arguments @('--abbrev-ref', 'HEAD')
    $gitDirectory = Invoke-GitRevParse -Root $resolvedRepository -Arguments @('--absolute-git-dir')
    $gitCommonDirectory = Invoke-GitRevParse -Root $resolvedRepository -Arguments @('--git-common-dir')
    if ($gitDirectory -and $gitCommonDirectory) {
        if (-not [System.IO.Path]::IsPathRooted($gitCommonDirectory)) {
            $gitCommonDirectory = [System.IO.Path]::GetFullPath((Join-Path $resolvedRepository $gitCommonDirectory))
        }
        $isWorktree = -not $gitDirectory.Equals($gitCommonDirectory, [System.StringComparison]::OrdinalIgnoreCase)
    }
}
if (-not $gitRoot) {
    Add-Issue -Code 'APPUI_GIT_METADATA_UNAVAILABLE' -Message 'Git worktree facts are unavailable for the supplied repository.'
}

$requiredDocumentNames = @('README.md', 'CHANGELOG.md', 'CONTRIBUTING.md', 'SECURITY.md')
$missingDocuments = @($requiredDocumentNames)
if ($repositoryRootRejected) {
    $layoutFacts = [ordered]@{
        packageManifest = $false
        releaseTools = $false
        consumerTemplate = $false
        validationProjectVersion = $false
        releaseTests = $false
        releaseToolsModule = $false
        requiredDocuments = $false
        missingDocuments = $missingDocuments
    }
}
else {
    $missingDocuments = @($requiredDocumentNames | Where-Object {
        -not (Test-RepositoryExpectedPath -Root $resolvedRepository -RelativePath $_ -PathType Leaf)
    })
    $layoutFacts = [ordered]@{
        packageManifest = $hasPackageManifest
        releaseTools = Test-RepositoryExpectedPath -Root $resolvedRepository -RelativePath 'Tools~\Release' -PathType Container
        consumerTemplate = Test-RepositoryExpectedPath -Root $resolvedRepository -RelativePath 'Validation~\Unity6000.0Consumer' -PathType Container
        validationProjectVersion = $hasValidationProjectVersion
        releaseTests = Test-RepositoryExpectedPath -Root $resolvedRepository -RelativePath 'Tools~\Release\Tests\Invoke-AppUIReleaseToolsTests.ps1' -PathType Leaf
        releaseToolsModule = Test-RepositoryExpectedPath -Root $resolvedRepository -RelativePath 'Tools~\Release\AppUI.ReleaseTools.psm1' -PathType Leaf
        requiredDocuments = $missingDocuments.Count -eq 0
        missingDocuments = $missingDocuments
    }
}

if ($repositoryBoundaryViolations.Count -gt 0) {
    Add-Issue -Code 'APPUI_REPOSITORY_BOUNDARY_VIOLATION' -Message 'Inspection refused one or more expected paths containing a reparse point.'
}

if (-not $layoutFacts.releaseTools) {
    Add-Issue -Code 'APPUI_RELEASE_TOOLS_MISSING' -Message 'Tools~/Release is missing.'
}
if (-not $layoutFacts.consumerTemplate) {
    Add-Issue -Code 'APPUI_CONSUMER_TEMPLATE_MISSING' -Message 'Validation~/Unity6000.0Consumer is missing.'
}
if (-not $layoutFacts.releaseTests) {
    Add-Issue -Code 'APPUI_RELEASE_TESTS_MISSING' -Message 'The release-tool test entry point is missing.'
}
if (-not $layoutFacts.releaseToolsModule) {
    Add-Issue -Code 'APPUI_RELEASE_TOOLS_MODULE_MISSING' -Message 'The repository-owned AppUI.ReleaseTools.psm1 module is missing.'
}
if (-not $layoutFacts.requiredDocuments) {
    Add-Issue -Code 'APPUI_REQUIRED_DOCUMENTS_MISSING' -Message 'One or more required public documents are missing.'
}

$repositoryFacts = [ordered]@{
    path = $resolvedRepository
    packageName = $packageName
    packageVersion = $packageVersion
    unityLine = $unityLine
    validationEditorVersion = $validationEditorVersion
    gitRoot = $gitRoot
    branch = $branch
    linkedWorktree = $isWorktree
}

$toolFacts = [ordered]@{
    operatingSystem = [System.Environment]::OSVersion.VersionString
    powerShellEdition = $PSVersionTable.PSEdition
    powerShellVersion = $PSVersionTable.PSVersion.ToString()
    externalProbesSkipped = [bool]$SkipExternalToolProbes
    git = [ordered]@{ available = $null; path = $null }
    githubCli = [ordered]@{ available = $null; path = $null; authenticated = $null; account = $null }
    unity = [ordered]@{
        available = $null
        exactVersionAvailable = $null
        selectedPath = $null
        selectedProductVersion = $null
        installations = @()
    }
    buildEnvironment = [ordered]@{ status = 'NotChecked' }
}

if ($SkipExternalToolProbes) {
    Add-Issue -Code 'APPUI_EXTERNAL_TOOL_PROBES_SKIPPED' -Message 'External tool probes were skipped, so declared toolchain readiness is unproven.'
}
else {
    $gitCommand = Get-Command git -ErrorAction SilentlyContinue
    $toolFacts.git.available = $null -ne $gitCommand
    $toolFacts.git.path = if ($gitCommand) { $gitCommand.Source } else { $null }
    if (-not $gitCommand) {
        Add-Issue -Code 'APPUI_GIT_MISSING' -Message 'Git is not available on PATH.'
    }

    $ghCommand = Get-Command gh -ErrorAction SilentlyContinue
    $toolFacts.githubCli.available = $null -ne $ghCommand
    $toolFacts.githubCli.path = if ($ghCommand) { $ghCommand.Source } else { $null }
    if ($ghCommand) {
        try {
            $authJson = & $ghCommand.Source auth status --active --json hosts 2>$null
            if ($LASTEXITCODE -eq 0 -and $authJson) {
                $authFacts = $authJson | ConvertFrom-Json
                $activeAccount = @($authFacts.hosts.PSObject.Properties.Value | ForEach-Object { $_ } |
                    Where-Object { $_.active -eq $true -and $_.state -eq 'success' } | Select-Object -First 1)
                $toolFacts.githubCli.authenticated = $activeAccount.Count -gt 0
                $toolFacts.githubCli.account = if ($activeAccount.Count -gt 0) { $activeAccount[0].login } else { $null }
            }
            else {
                $toolFacts.githubCli.authenticated = $false
            }
        }
        catch {
            $toolFacts.githubCli.authenticated = $false
        }
        if (-not $toolFacts.githubCli.authenticated) {
            Add-Issue -Code 'APPUI_GITHUB_AUTH_MISSING' -Message 'GitHub CLI has no active authenticated account.'
        }
    }
    else {
        Add-Issue -Code 'APPUI_GITHUB_CLI_MISSING' -Message 'GitHub CLI is not available on PATH.'
    }

    $unityCandidates = [System.Collections.Generic.List[string]]::new()
    if ($UnityPath) {
        Add-UnityCandidate -Candidates $unityCandidates -CandidatePath $UnityPath
    }
    foreach ($unityRoot in @('C:\Unity', 'C:\Program Files\Unity\Hub\Editor')) {
        if (Test-Path -LiteralPath $unityRoot -PathType Container) {
            Add-UnityCandidate -Candidates $unityCandidates -CandidatePath $unityRoot
            foreach ($child in @(Get-ChildItem -LiteralPath $unityRoot -Directory -ErrorAction SilentlyContinue)) {
                Add-UnityCandidate -Candidates $unityCandidates -CandidatePath $child.FullName
            }
        }
    }
    $unityInstallations = @($unityCandidates | ForEach-Object {
        [ordered]@{ path = $_; productVersion = Get-UnityProductVersion -EditorPath $_ }
    })
    $toolFacts.unity.installations = $unityInstallations
    $toolFacts.unity.available = $unityCandidates.Count -gt 0
    $selectedUnity = @($unityInstallations | Where-Object {
        $validationEditorVersion -and $_.productVersion -ceq $validationEditorVersion
    } | Select-Object -First 1)
    $toolFacts.unity.exactVersionAvailable = $selectedUnity.Count -eq 1
    if ($selectedUnity.Count -eq 1) {
        $toolFacts.unity.selectedPath = $selectedUnity[0].path
        $toolFacts.unity.selectedProductVersion = $selectedUnity[0].productVersion
    }
    if (-not $toolFacts.unity.available) {
        Add-Issue -Code 'APPUI_UNITY_MISSING' -Message 'No Unity Editor was found in the supplied or standard installation roots.'
    }
    elseif ($validationEditorVersion -and -not $toolFacts.unity.exactVersionAvailable) {
        Add-Issue -Code 'APPUI_UNITY_EDITOR_PIN_UNAVAILABLE' -Message 'No discovered Unity Editor ProductVersion equals the validation pin.'
    }

    if ($toolFacts.unity.exactVersionAvailable -and $layoutFacts.releaseToolsModule -and
        $unityLine -and $validationUnityLine -and $unityLine -ceq $validationUnityLine) {
        $importedReleaseTools = $null
        try {
            $releaseToolsModulePath = Join-Path $resolvedRepository 'Tools~\Release\AppUI.ReleaseTools.psm1'
            $importedReleaseTools = Import-Module -Name $releaseToolsModulePath -Force -PassThru -ErrorAction Stop
            $buildEnvironmentCommand = Get-Command -Name 'Test-AppUIBuildEnvironment' `
                -Module $importedReleaseTools.Name -ErrorAction Stop
            $gateOutput = @(& $buildEnvironmentCommand -UnityPath $toolFacts.unity.selectedPath `
                -ExpectedUnityVersion $validationEditorVersion)
            if ($gateOutput.Count -eq 1 -and $gateOutput[0].schemaVersion -is [string] -and
                $gateOutput[0].schemaVersion -ceq 'appui-build-environment.v1' -and
                $gateOutput[0].status -is [string] -and
                $gateOutput[0].status -ceq 'Passed') {
                $toolFacts.buildEnvironment.status = 'Ready'
            }
            else {
                $toolFacts.buildEnvironment.status = 'Blocked'
                Add-Issue -Code 'APPUI_BUILD_ENVIRONMENT_BLOCKED' -Message 'The repository-owned Windows IL2CPP/C++ build-environment gate returned Blocked.'
            }
        }
        catch {
            $toolFacts.buildEnvironment.status = 'Blocked'
            Add-Issue -Code 'APPUI_BUILD_ENVIRONMENT_GATE_FAILED' -Message 'The repository-owned Windows IL2CPP/C++ build-environment gate could not be invoked.'
        }
        finally {
            if ($importedReleaseTools) {
                Remove-Module -ModuleInfo $importedReleaseTools -Force -ErrorAction SilentlyContinue
            }
        }
    }
}

$result = [ordered]@{
    schemaVersion = 'joih-appui-maintainer-environment.v1'
    status = if ($issues.Count -eq 0) { 'Ready' } else { 'Blocked' }
    repository = $repositoryFacts
    tools = $toolFacts
    layout = $layoutFacts
    issues = @($issues)
}

$json = $result | ConvertTo-Json -Depth 20
if ($OutputPath) {
    $absoluteOutputPath = [System.IO.Path]::GetFullPath($OutputPath)
    [System.IO.File]::WriteAllText($absoluteOutputPath, $json, [System.Text.UTF8Encoding]::new($false))
}
Write-Output $result

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$RepositoryPath,
    [string]$GitPath = '',
    [string]$GhPath = '',
    [string]$RemoteName = 'origin',
    [ValidateRange(1, 300)][int]$TimeoutSeconds = 30,
    [string]$CandidateEvidencePath = '',
    [string]$OutputPath = ''
)

$ErrorActionPreference = 'Stop'
$reasons = [System.Collections.Generic.List[string]]::new()

function Add-Reason {
    param([Parameter(Mandatory = $true)][string]$Code)

    if (-not $reasons.Contains($Code)) {
        $reasons.Add($Code)
    }
}

function ConvertTo-CommandLineArgument {
    param([Parameter(Mandatory = $true)][AllowEmptyString()][string]$Value)

    if ($Value.Length -gt 0 -and $Value -notmatch '[\s"]') {
        return $Value
    }

    $builder = [System.Text.StringBuilder]::new()
    [void]$builder.Append('"')
    $backslashes = 0
    foreach ($character in $Value.ToCharArray()) {
        if ($character -eq '\') {
            $backslashes++
            continue
        }

        if ($character -eq '"') {
            [void]$builder.Append(('\' * (($backslashes * 2) + 1)))
            [void]$builder.Append('"')
        }
        else {
            if ($backslashes -gt 0) {
                [void]$builder.Append(('\' * $backslashes))
            }
            [void]$builder.Append($character)
        }
        $backslashes = 0
    }
    if ($backslashes -gt 0) {
        [void]$builder.Append(('\' * ($backslashes * 2)))
    }
    [void]$builder.Append('"')
    return $builder.ToString()
}

function Test-BatchExecutablePathSafe {
    param([Parameter(Mandatory = $true)][string]$ExecutablePath)

    $extension = [System.IO.Path]::GetExtension($ExecutablePath)
    if ($extension -ine '.cmd' -and $extension -ine '.bat') {
        return $true
    }
    return $ExecutablePath -match '^[A-Za-z0-9_ .:\\/-]+$'
}

function Test-BatchArgumentSafe {
    param([Parameter(Mandatory = $true)][AllowEmptyString()][string]$Value)

    return $Value -match '^[A-Za-z0-9_./:\\?=-]+$'
}

function Resolve-ExecutablePath {
    param(
        [Parameter(Mandatory = $true)][AllowEmptyString()][string]$RequestedPath,
        [Parameter(Mandatory = $true)][string]$CommandName
    )

    if ($RequestedPath) {
        $item = Get-Item -LiteralPath $RequestedPath -Force -ErrorAction SilentlyContinue
        if ($item -and -not $item.PSIsContainer) {
            return $item.FullName
        }
        return $null
    }

    $command = Get-Command $CommandName -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($command) {
        return $command.Source
    }
    return $null
}

function Stop-WindowsProcessTree {
    param([Parameter(Mandatory = $true)][System.Diagnostics.Process]$Process)

    $taskkillPath = Join-Path $env:SystemRoot 'System32\taskkill.exe'
    if (Test-Path -LiteralPath $taskkillPath -PathType Leaf) {
        $treeKiller = [System.Diagnostics.Process]::new()
        $treeKiller.StartInfo = [System.Diagnostics.ProcessStartInfo]::new()
        $treeKiller.StartInfo.FileName = $taskkillPath
        $treeKiller.StartInfo.Arguments = "/PID $($Process.Id) /T /F"
        $treeKiller.StartInfo.UseShellExecute = $false
        $treeKiller.StartInfo.CreateNoWindow = $true
        $treeKiller.StartInfo.RedirectStandardOutput = $true
        $treeKiller.StartInfo.RedirectStandardError = $true
        try {
            [void]$treeKiller.Start()
            if (-not $treeKiller.WaitForExit(5000)) {
                $treeKiller.Kill()
            }
        }
        catch {
        }
        finally {
            $treeKiller.Dispose()
        }
    }

    try {
        if (-not $Process.HasExited) {
            $Process.Kill()
        }
    }
    catch {
    }
}

function Invoke-BoundedProcess {
    param(
        [Parameter(Mandatory = $true)][string]$ExecutablePath,
        [Parameter(Mandatory = $true)][AllowEmptyCollection()][string[]]$Arguments,
        [Parameter(Mandatory = $true)][int]$BoundedTimeoutSeconds
    )

    $process = [System.Diagnostics.Process]::new()
    $startInfo = [System.Diagnostics.ProcessStartInfo]::new()
    $extension = [System.IO.Path]::GetExtension($ExecutablePath)
    if (($extension -ieq '.cmd' -or $extension -ieq '.bat') -and
        (-not (Test-BatchExecutablePathSafe -ExecutablePath $ExecutablePath) -or
            @($Arguments | Where-Object { -not (Test-BatchArgumentSafe -Value $_) }).Count -gt 0)) {
        $process.Dispose()
        return [pscustomobject][ordered]@{
            started = $false
            timedOut = $false
            exitCode = $null
            standardOutput = ''
            standardError = ''
        }
    }
    $argumentText = @($Arguments | ForEach-Object { ConvertTo-CommandLineArgument -Value $_ }) -join ' '
    if ($extension -ieq '.cmd' -or $extension -ieq '.bat') {
        $startInfo.FileName = $env:ComSpec
        $commandText = (ConvertTo-CommandLineArgument -Value $ExecutablePath)
        if ($argumentText) {
            $commandText += " $argumentText"
        }
        $startInfo.Arguments = "/d /s /c `"$commandText`""
    }
    else {
        $startInfo.FileName = $ExecutablePath
        $startInfo.Arguments = $argumentText
    }
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $startInfo.StandardOutputEncoding = [System.Text.Encoding]::UTF8
    $startInfo.StandardErrorEncoding = [System.Text.Encoding]::UTF8
    $process.StartInfo = $startInfo

    try {
        [void]$process.Start()
    }
    catch {
        $process.Dispose()
        return [pscustomobject][ordered]@{
            started = $false
            timedOut = $false
            exitCode = $null
            standardOutput = ''
            standardError = ''
        }
    }

    $standardOutput = $process.StandardOutput.ReadToEndAsync()
    $standardError = $process.StandardError.ReadToEndAsync()
    $finished = $process.WaitForExit($BoundedTimeoutSeconds * 1000)
    if (-not $finished) {
        Stop-WindowsProcessTree -Process $process
        [void]$process.WaitForExit(2000)
    }
    else {
        $process.WaitForExit()
    }

    $exitCode = if ($finished) { $process.ExitCode } else { $null }
    $stdoutText = if ($standardOutput.IsCompleted) { $standardOutput.Result } else { '' }
    $stderrText = if ($standardError.IsCompleted) { $standardError.Result } else { '' }
    $process.Dispose()
    return [pscustomobject][ordered]@{
        started = $true
        timedOut = -not $finished
        exitCode = $exitCode
        standardOutput = $stdoutText
        standardError = $stderrText
    }
}

function Invoke-ReadOnlyGit {
    param(
        [Parameter(Mandatory = $true)][string]$ExecutablePath,
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [Parameter(Mandatory = $true)][int]$BoundedTimeoutSeconds
    )

    $gitArguments = @('--no-optional-locks', '-C', $Root) + $Arguments
    return Invoke-BoundedProcess -ExecutablePath $ExecutablePath -Arguments $gitArguments -BoundedTimeoutSeconds $BoundedTimeoutSeconds
}

function Get-FirstOutputLine {
    param([Parameter(Mandatory = $true)]$ProcessResult)

    if (-not $ProcessResult.started -or $ProcessResult.timedOut -or $ProcessResult.exitCode -ne 0) {
        return $null
    }
    $line = @($ProcessResult.standardOutput -split "`r?`n" | Where-Object { $_ } | Select-Object -First 1)
    if ($line.Count -eq 0) {
        return $null
    }
    return $line[0].Trim()
}

function ConvertTo-RemoteIdentity {
    param([Parameter(Mandatory = $true)][string]$RemoteUrl)

    $hostName = $null
    $repositoryName = $null
    if ($RemoteUrl -match '^https://([^/]+)/([^/]+/[^/]+?)(?:\.git)?/?$') {
        $hostName = $Matches[1].ToLowerInvariant()
        $repositoryName = $Matches[2]
    }
    elseif ($RemoteUrl -match '^[^@]+@([^:]+):([^/]+/[^/]+?)(?:\.git)?$') {
        $hostName = $Matches[1].ToLowerInvariant()
        $repositoryName = $Matches[2]
    }
    elseif ($RemoteUrl -match '^ssh://(?:[^@/]+@)?([^/]+)/([^/]+/[^/]+?)(?:\.git)?/?$') {
        $hostName = $Matches[1].ToLowerInvariant()
        $repositoryName = $Matches[2]
    }

    $repositoryValid = $null -ne $repositoryName -and $repositoryName -match '^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$'
    return [pscustomobject][ordered]@{
        host = $hostName
        repository = $repositoryName
        repositoryValid = $repositoryValid
        supported = $hostName -eq 'github.com' -and $repositoryValid
    }
}

$resolvedRepository = $null
$repositoryRootRejected = $false
$repositoryItem = Get-Item -LiteralPath $RepositoryPath -Force -ErrorAction SilentlyContinue
if (-not $repositoryItem -or -not $repositoryItem.PSIsContainer) {
    Add-Reason -Code 'REPOSITORY_UNAVAILABLE'
}
else {
    $resolvedRepository = $repositoryItem.FullName
    $repositoryRootRejected = ($repositoryItem.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0
    if ($repositoryRootRejected) {
        Add-Reason -Code 'REPOSITORY_BOUNDARY_VIOLATION'
    }
}

$resolvedGitPath = Resolve-ExecutablePath -RequestedPath $GitPath -CommandName 'git'
$resolvedGhPath = Resolve-ExecutablePath -RequestedPath $GhPath -CommandName 'gh'
$remoteNameValid = $RemoteName -match '^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$'
$ghInvocationPathSafe = -not $resolvedGhPath -or (Test-BatchExecutablePathSafe -ExecutablePath $resolvedGhPath)
if (-not $resolvedGitPath) {
    Add-Reason -Code 'GIT_UNAVAILABLE'
}
if (-not $resolvedGhPath) {
    Add-Reason -Code 'GITHUB_CLI_UNAVAILABLE'
}
if (-not $remoteNameValid) {
    Add-Reason -Code 'REMOTE_NAME_INVALID'
}
if (-not $ghInvocationPathSafe) {
    Add-Reason -Code 'BATCH_EXECUTABLE_PATH_UNSAFE'
}

$packageVersion = $null
$plannedTag = $null
if ($resolvedRepository -and -not $repositoryRootRejected) {
    $packagePath = Join-Path $resolvedRepository 'package.json'
    $packageItem = Get-Item -LiteralPath $packagePath -Force -ErrorAction SilentlyContinue
    if (-not $packageItem -or $packageItem.PSIsContainer -or
        ($packageItem.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
        Add-Reason -Code 'PACKAGE_MANIFEST_MISSING'
    }
    else {
        try {
            $packageManifest = Get-Content -LiteralPath $packagePath -Raw -Encoding UTF8 | ConvertFrom-Json
            $safePackageVersionPattern = '^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(?:-[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$'
            if ($packageManifest.version -isnot [string] -or $packageManifest.version -notmatch $safePackageVersionPattern) {
                Add-Reason -Code 'PACKAGE_VERSION_INVALID'
            }
            else {
                $packageVersion = $packageManifest.version
                $plannedTag = "v$packageVersion"
            }
        }
        catch {
            Add-Reason -Code 'PACKAGE_MANIFEST_INVALID'
        }
    }
}

$sourceCommit = $null
$sourceTree = $null
$workingTreeDirty = $false
$gitRootAvailable = $false
$gitRootMatchesRepository = $false
if ($resolvedRepository -and -not $repositoryRootRejected -and $resolvedGitPath) {
    $gitRootResult = Invoke-ReadOnlyGit -ExecutablePath $resolvedGitPath -Root $resolvedRepository -Arguments @('rev-parse', '--show-toplevel') -BoundedTimeoutSeconds $TimeoutSeconds
    $gitRoot = Get-FirstOutputLine -ProcessResult $gitRootResult
    $gitRootAvailable = $null -ne $gitRoot
    if ($gitRootAvailable) {
        $normalizedGitRoot = [System.IO.Path]::GetFullPath($gitRoot).TrimEnd(
            [System.IO.Path]::DirectorySeparatorChar, [System.IO.Path]::AltDirectorySeparatorChar)
        $normalizedRepository = [System.IO.Path]::GetFullPath($resolvedRepository).TrimEnd(
            [System.IO.Path]::DirectorySeparatorChar, [System.IO.Path]::AltDirectorySeparatorChar)
        $gitRootMatchesRepository = $normalizedGitRoot.Equals($normalizedRepository, [System.StringComparison]::OrdinalIgnoreCase)
    }

    $commitResult = Invoke-ReadOnlyGit -ExecutablePath $resolvedGitPath -Root $resolvedRepository -Arguments @('rev-parse', '--verify', 'HEAD') -BoundedTimeoutSeconds $TimeoutSeconds
    $treeResult = Invoke-ReadOnlyGit -ExecutablePath $resolvedGitPath -Root $resolvedRepository -Arguments @('rev-parse', '--verify', 'HEAD^{tree}') -BoundedTimeoutSeconds $TimeoutSeconds
    $statusResult = Invoke-ReadOnlyGit -ExecutablePath $resolvedGitPath -Root $resolvedRepository -Arguments @('status', '--porcelain=v1', '--untracked-files=normal') -BoundedTimeoutSeconds $TimeoutSeconds
    $sourceCommit = Get-FirstOutputLine -ProcessResult $commitResult
    $sourceTree = Get-FirstOutputLine -ProcessResult $treeResult
    if ($statusResult.started -and -not $statusResult.timedOut -and $statusResult.exitCode -eq 0) {
        $workingTreeDirty = -not [string]::IsNullOrWhiteSpace($statusResult.standardOutput)
    }
    else {
        $gitRootAvailable = $false
    }
}
if (-not $gitRootAvailable -or $sourceCommit -notmatch '^[0-9a-f]{40}$' -or $sourceTree -notmatch '^[0-9a-f]{40}$') {
    Add-Reason -Code 'GIT_METADATA_UNAVAILABLE'
}
if ($gitRootAvailable -and -not $gitRootMatchesRepository) {
    Add-Reason -Code 'REPOSITORY_GIT_ROOT_MISMATCH'
}

$environmentReady = $resolvedRepository -and -not $repositoryRootRejected -and $resolvedGitPath -and $resolvedGhPath -and
    $remoteNameValid -and $ghInvocationPathSafe -and $gitRootMatchesRepository -and
    $packageVersion -and $plannedTag -and $gitRootAvailable -and
    $sourceCommit -match '^[0-9a-f]{40}$' -and $sourceTree -match '^[0-9a-f]{40}$'

$candidateEvidenceProvided = -not [string]::IsNullOrWhiteSpace($CandidateEvidencePath)
$candidateEvidenceVerified = $false
$candidateEvidenceStatus = $null
$candidateEvidenceMode = $null
$candidateEvidenceInvalid = $false
if ($candidateEvidenceProvided) {
    $candidateEvidenceItem = Get-Item -LiteralPath $CandidateEvidencePath -Force -ErrorAction SilentlyContinue
    if (-not $candidateEvidenceItem -or $candidateEvidenceItem.PSIsContainer) {
        $candidateEvidenceInvalid = $true
    }
    else {
        try {
            $candidateEvidenceRecord = Get-Content -LiteralPath $candidateEvidenceItem.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
            $candidateEvidenceWellFormed = $candidateEvidenceRecord.status -is [string] -and
                $candidateEvidenceRecord.mode -is [string] -and
                $candidateEvidenceRecord.sourceCommit -is [string] -and
                $candidateEvidenceRecord.sourceTree -is [string] -and
                $candidateEvidenceRecord.packageVersion -is [string] -and
                $candidateEvidenceRecord.plannedTag -is [string]
            if (-not $candidateEvidenceWellFormed) {
                $candidateEvidenceInvalid = $true
            }
            else {
                $candidateEvidenceStatus = if ($candidateEvidenceRecord.status -ceq 'Passed') { 'Passed' } else { $null }
                $candidateEvidenceMode = if ($candidateEvidenceRecord.mode -ceq 'PreTag') { 'PreTag' } else { $null }
                $candidateEvidenceVerified = $candidateEvidenceRecord.status -ceq 'Passed' -and
                    $candidateEvidenceRecord.mode -ceq 'PreTag' -and
                    $candidateEvidenceRecord.sourceCommit -ceq $sourceCommit -and
                    $candidateEvidenceRecord.sourceTree -ceq $sourceTree -and
                    $candidateEvidenceRecord.packageVersion -ceq $packageVersion -and
                    $candidateEvidenceRecord.plannedTag -ceq $plannedTag
            }
        }
        catch {
            $candidateEvidenceInvalid = $true
        }
    }
}

$remoteUrl = $null
$remoteMainCommit = $null
$remoteQueryBlocked = $false
$candidatePushed = $false
$tagExists = $false
$tagAnnotated = $false
$tagObjectId = $null
$peeledTagCommit = $null
$tagIdentityVerified = $false
$tagConflict = $false
$releaseExists = $false
$releaseCompatible = $false
$releaseQueryAmbiguous = $false
$releaseUrl = $null
$releaseIsDraft = $null
$releaseIsPrerelease = $null
$githubRepository = $null
$remoteHost = $null
$packageIsPrerelease = $packageVersion -match '-'

if ($environmentReady) {
    $remoteUrlResult = Invoke-ReadOnlyGit -ExecutablePath $resolvedGitPath -Root $resolvedRepository -Arguments @('config', '--get', "remote.$RemoteName.url") -BoundedTimeoutSeconds $TimeoutSeconds
    $remoteUrl = Get-FirstOutputLine -ProcessResult $remoteUrlResult
    if (-not $remoteUrl) {
        $remoteQueryBlocked = $true
    }
    else {
        $remoteMainResult = Invoke-ReadOnlyGit -ExecutablePath $resolvedGitPath -Root $resolvedRepository -Arguments @('ls-remote', '--heads', $RemoteName, 'refs/heads/main') -BoundedTimeoutSeconds $TimeoutSeconds
        if (-not $remoteMainResult.started -or $remoteMainResult.timedOut -or $remoteMainResult.exitCode -ne 0) {
            $remoteQueryBlocked = $true
        }
        elseif (-not [string]::IsNullOrWhiteSpace($remoteMainResult.standardOutput)) {
            $remoteMainLines = @($remoteMainResult.standardOutput -split "`r?`n" | Where-Object { $_ })
            if ($remoteMainLines.Count -ne 1 -or $remoteMainLines[0] -notmatch '^([0-9a-f]{40})\s+refs/heads/main$') {
                $remoteQueryBlocked = $true
            }
            else {
                $remoteMainCommit = $Matches[1]
            }
        }
        $candidatePushed = $remoteMainCommit -eq $sourceCommit

        $tagResult = Invoke-ReadOnlyGit -ExecutablePath $resolvedGitPath -Root $resolvedRepository -Arguments @(
            'ls-remote', '--tags', $RemoteName, "refs/tags/$plannedTag", "refs/tags/$plannedTag^{}"
        ) -BoundedTimeoutSeconds $TimeoutSeconds
        if (-not $tagResult.started -or $tagResult.timedOut -or $tagResult.exitCode -ne 0) {
            $remoteQueryBlocked = $true
        }
        else {
            $tagLines = @($tagResult.standardOutput -split "`r?`n" | Where-Object { $_ })
            $baseTagIds = [System.Collections.Generic.List[string]]::new()
            $peeledTagIds = [System.Collections.Generic.List[string]]::new()
            $tagPattern = [regex]::Escape($plannedTag)
            foreach ($line in $tagLines) {
                if ($line -match "^([0-9a-f]{40})\s+refs/tags/$tagPattern$") {
                    $baseTagIds.Add($Matches[1])
                }
                elseif ($line -match "^([0-9a-f]{40})\s+refs/tags/$tagPattern\^\{\}$") {
                    $peeledTagIds.Add($Matches[1])
                }
                else {
                    $remoteQueryBlocked = $true
                }
            }
            $validTagCardinality = ($baseTagIds.Count -eq 0 -and $peeledTagIds.Count -eq 0) -or
                ($baseTagIds.Count -eq 1 -and $peeledTagIds.Count -eq 0) -or
                ($baseTagIds.Count -eq 1 -and $peeledTagIds.Count -eq 1 -and $baseTagIds[0] -ne $peeledTagIds[0])
            if (-not $validTagCardinality) {
                $remoteQueryBlocked = $true
            }
            elseif ($baseTagIds.Count -eq 1) {
                $tagObjectId = $baseTagIds[0]
                $tagExists = $true
                if ($peeledTagIds.Count -eq 1) {
                    $peeledTagCommit = $peeledTagIds[0]
                }
            }
            $tagAnnotated = $tagExists -and $null -ne $peeledTagCommit
            $tagIdentityVerified = $tagAnnotated -and $peeledTagCommit -eq $sourceCommit
            $tagConflict = $tagExists -and (-not $tagAnnotated -or $peeledTagCommit -ne $sourceCommit)
        }
    }

    $remoteIdentity = if ($remoteUrl) { ConvertTo-RemoteIdentity -RemoteUrl $remoteUrl } else { $null }
    $remoteHost = if ($remoteIdentity) { $remoteIdentity.host } else { $null }
    $githubRepository = if ($remoteIdentity -and $remoteIdentity.supported) { $remoteIdentity.repository } else { $null }
    if (-not $githubRepository) {
        $releaseQueryAmbiguous = $true
    }
    else {
        $encodedTag = [System.Uri]::EscapeDataString($plannedTag)
        $releaseEndpoint = "repos/$githubRepository/releases/tags/$encodedTag"
        $releaseResult = Invoke-BoundedProcess -ExecutablePath $resolvedGhPath -Arguments @(
            'api', '--method', 'GET', $releaseEndpoint
        ) -BoundedTimeoutSeconds $TimeoutSeconds
        if (-not $releaseResult.started -or $releaseResult.timedOut -or
            [string]::IsNullOrWhiteSpace($releaseResult.standardOutput)) {
            $releaseQueryAmbiguous = $true
        }
        else {
            try {
                $releaseRecord = $releaseResult.standardOutput | ConvertFrom-Json
                if ($releaseResult.exitCode -eq 0) {
                    if ($releaseRecord.tag_name -isnot [string] -or
                        $releaseRecord.html_url -isnot [string] -or [string]::IsNullOrWhiteSpace($releaseRecord.html_url) -or
                        $releaseRecord.draft -isnot [bool] -or $releaseRecord.prerelease -isnot [bool]) {
                        $releaseQueryAmbiguous = $true
                    }
                    else {
                        $releaseExists = $true
                        $releaseUrl = $releaseRecord.html_url
                        $releaseIsDraft = $releaseRecord.draft
                        $releaseIsPrerelease = $releaseRecord.prerelease
                        $expectedReleaseUrl = "https://github.com/$githubRepository/releases/tag/$encodedTag"
                        $releaseCompatible = $releaseRecord.tag_name -ceq $plannedTag -and
                            $releaseUrl -ceq $expectedReleaseUrl -and
                            -not $releaseIsDraft -and $releaseIsPrerelease -eq $packageIsPrerelease
                    }
                }
                elseif ("$($releaseRecord.status)" -ne '404') {
                    $releaseQueryAmbiguous = $true
                }
            }
            catch {
                $releaseQueryAmbiguous = $true
            }
        }
    }
}

if ($workingTreeDirty) {
    Add-Reason -Code 'WORKING_TREE_DIRTY'
}
if ($remoteQueryBlocked) {
    Add-Reason -Code 'REMOTE_QUERY_BLOCKED'
}
if ($releaseQueryAmbiguous) {
    Add-Reason -Code 'RELEASE_QUERY_AMBIGUOUS'
}
if ($environmentReady -and $remoteUrl -and $remoteHost -eq 'github.com' -and -not $remoteIdentity.repositoryValid) {
    Add-Reason -Code 'REMOTE_REPOSITORY_INVALID'
}
elseif ($environmentReady -and $remoteUrl -and -not $githubRepository) {
    Add-Reason -Code 'UNSUPPORTED_REMOTE_HOST'
}
if ($environmentReady -and -not $remoteQueryBlocked -and -not $tagExists -and
    $candidateEvidenceVerified -and -not $candidatePushed) {
    Add-Reason -Code 'CANDIDATE_NOT_PUSHED'
}
if ($tagConflict) {
    Add-Reason -Code $(if (-not $tagAnnotated) { 'TAG_NOT_ANNOTATED' } else { 'TAG_COMMIT_CONFLICT' })
}
if ($environmentReady -and -not $remoteQueryBlocked -and -not $tagExists) {
    Add-Reason -Code 'TAG_MISSING'
}
if ($environmentReady -and -not $remoteQueryBlocked -and -not $tagExists -and -not $candidateEvidenceVerified) {
    if (-not $candidateEvidenceProvided) {
        Add-Reason -Code 'CANDIDATE_EVIDENCE_MISSING'
    }
    elseif ($candidateEvidenceInvalid) {
        Add-Reason -Code 'CANDIDATE_EVIDENCE_INVALID'
    }
    else {
        Add-Reason -Code 'CANDIDATE_EVIDENCE_MISMATCH'
    }
}
if ($tagExists -and -not $releaseExists -and -not $releaseQueryAmbiguous) {
    Add-Reason -Code 'RELEASE_MISSING'
}
if ($tagExists -and $releaseExists -and -not $releaseCompatible) {
    if ($releaseRecord.tag_name -cne $plannedTag) {
        Add-Reason -Code 'RELEASE_TAG_MISMATCH'
    }
    $expectedReleaseUrl = "https://github.com/$githubRepository/releases/tag/$([System.Uri]::EscapeDataString($plannedTag))"
    if ($releaseUrl -cne $expectedReleaseUrl) {
        Add-Reason -Code 'RELEASE_URL_MISMATCH'
    }
    if ($releaseIsDraft) {
        Add-Reason -Code 'RELEASE_DRAFT'
    }
    if ($releaseIsPrerelease -ne $packageIsPrerelease) {
        Add-Reason -Code 'RELEASE_PRERELEASE_MISMATCH'
    }
}

$status = if (-not $environmentReady) {
    'EnvironmentBlocked'
}
elseif ($workingTreeDirty) {
    'WorkingTreeDirty'
}
elseif ($remoteQueryBlocked -or $releaseQueryAmbiguous) {
    'RemoteStateAmbiguous'
}
elseif ($tagConflict) {
    'FailedReleaseAttempt'
}
elseif ($tagExists) {
    if ($tagIdentityVerified -and $releaseCompatible) { 'Published' } else { 'TagExistsUnverified' }
}
elseif (-not $candidateEvidenceVerified) {
    'CandidateUnverified'
}
elseif (-not $candidatePushed) {
    'CandidateNotPushed'
}
else {
    'ReadyForTag'
}

$result = [ordered]@{
    schemaVersion = 'joih-appui-release-state.v1'
    status = $status
    repository = [ordered]@{
        path = $resolvedRepository
        remoteName = $RemoteName
        remoteHost = $remoteHost
        remoteRepository = $githubRepository
    }
    sourceCommit = $sourceCommit
    sourceTree = $sourceTree
    packageVersion = $packageVersion
    plannedTag = $plannedTag
    workingTreeDirty = $workingTreeDirty
    remoteMainCommit = $remoteMainCommit
    remoteQueryBlocked = $remoteQueryBlocked
    candidatePushed = $candidatePushed
    candidateEvidence = [ordered]@{
        provided = $candidateEvidenceProvided
        verified = $candidateEvidenceVerified
        status = $candidateEvidenceStatus
        mode = $candidateEvidenceMode
    }
    tag = [ordered]@{
        exists = $tagExists
        annotated = $tagAnnotated
        objectId = $tagObjectId
        peeledCommit = $peeledTagCommit
        identityVerified = $tagIdentityVerified
        conflict = $tagConflict
    }
    release = [ordered]@{
        exists = $releaseExists
        compatible = $releaseCompatible
        queryAmbiguous = $releaseQueryAmbiguous
        url = $releaseUrl
        isDraft = $releaseIsDraft
        isPrerelease = $releaseIsPrerelease
    }
    reasons = @($reasons)
}

$json = $result | ConvertTo-Json -Depth 20
if ($OutputPath) {
    $absoluteOutputPath = [System.IO.Path]::GetFullPath($OutputPath)
    [System.IO.File]::WriteAllText($absoluteOutputPath, $json, [System.Text.UTF8Encoding]::new($false))
}
Write-Output $result

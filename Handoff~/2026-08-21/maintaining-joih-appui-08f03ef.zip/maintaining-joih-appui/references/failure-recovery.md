# Failure recovery

Every case starts identically: stop mutation, preserve logs/evidence and unrelated
work, rerun both skill inspectors, run the repository's read-only
`Test-AppUIReleaseReadiness.ps1`, and reconcile exact local/remote Commit, Tree,
version Tag, and GitHub Release facts. A timeout or nonzero command result does not
prove that a mutation failed.

| Observed state after reconciliation | Safe decision |
| --- | --- |
| `RemoteStateAmbiguous` | Do not push, Tag, upload, delete, or retry. Repeat bounded read-only queries after connectivity/auth is restored. Release-state v1 intentionally treats GitHub Enterprise Server and non-GitHub provenance as ambiguous. Escalate if exact absence/presence cannot be proven. |
| Local-only Tag | Prove remote absence and inspect the local Tag object, annotation, peeled Commit, Tree, and prior gate evidence. Resume by pushing that existing ref only if no post-Tag command was attempted or failed and it is the exact authorized, fully validated candidate. A failed/interrupted Tag push, wrong identity, or invalid evidence is a `Failed Release Attempt`: do not publish or rewrite it; preserve the record and choose a new SemVer version. |
| Remote annotated Tag | Prove its peeled Commit/Tree. If Tag smoke has never run and all preceding gates passed, run one fresh Tag URL smoke. If any post-Tag gate already failed, classify `Failed Release Attempt`; do not continue the same version. A conflicting or lightweight Tag is never repaired in place. |
| Failed Tag URL smoke | Preserve Tag and failed evidence, create no Release, remove no remote state, and do not claim support. Fix the cause in a new candidate, choose a new SemVer version, and restart all gates. |
| Failed artifact/sanitizing audit | Preserve Tag and rejected stage, create no Release, and record `Failed Release Attempt`. Fix the evidence/tooling boundary, choose a new version, and regenerate every gate and artifact from one new Commit/Tree. |
| Partial Release upload or uncertain `gh release create` result | Query the exact Tag Release and assets; do not rerun create/upload. If incomplete, do not mark supported or silently repair the same version. Preserve Tag/Release facts, report the failed attempt, and request a separate decision for any remote cleanup; corrected publication uses a new version. |
| Published Release | Treat inspector `Published` only as exact remote Tag/Release reconciliation. Do not recreate or edit it as a retry. Independently verify the Passed Commit URL smoke and Tag URL smoke reports, Tag identity, flags, unique uploaded asset set, remote digests, and local hash map. If all pass, continue only missing post-release docs/audit with separate push authorization. Missing or failed smoke is never inferred from Git identity. If immutable identity, smoke, or assets fail, preserve evidence, remove support claims, escalate, and correct with a new version; never move the Tag. |

## Report shape

Return the inspector statuses and reason codes, exact Commit/Tree/version/Tag,
candidate-evidence `provided`/`verified` facts,
which remote facts are proven versus ambiguous, last passed gate, first failed or
blocked gate, whether any external mutation is known to have occurred, and one
safe next action. Never include credentials or machine-specific paths.

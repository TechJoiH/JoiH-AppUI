# Repository map

Use the current tree, public docs, asmdefs, and tests as authority. Do not infer
ownership from directory names alone after the repository changes.

| Area | Ownership and maintenance boundary |
| --- | --- |
| `Runtime/` | Public Core contracts plus page, layer, lifecycle, input, focus, binding, notice, operation, and runtime orchestration. Keep public APIs backend-neutral. Runtime behavior or API changes require matching contract tests, `CHANGELOG.md`, and affected public docs/migration guidance. |
| `Editor/` | Base authoring, Binding, input, selection, generation, and validation tooling. Changes require Editor tests and updates to Binding/editor workflow docs when user-visible behavior changes. |
| `Integrations/` | Optional, one-way integrations such as TextMeshPro. They may depend on Base; Base must not depend on them. Integration contract changes require their tests, Sample, integration docs, and release-profile coverage. |
| `Samples~/` | Public, importable composition examples: Basic, Custom Host, and optional TextMeshPro. A Sample is consumer-owned example code, not a Runtime default. User-facing changes require the Sample README and relevant onboarding/migration docs. |
| `Tests/` | Package-internal EditMode/PlayMode and contract fixtures. These catch regressions but do not prove UPM installation or replace external Consumers. |
| `Validation~/` | Repository-owned external Consumer template for the single official Unity line. Release tools materialize clean Base and TextMeshPro Consumers outside the repository; do not validate by opening the template in place. |
| `Tools~/Release/` | Authoritative snapshot, policy, Consumer, Unity gate, smoke, report, sanitizing, artifact, and readiness implementation. Any contract/schema/artifact change requires release-tool tests and `Documentation~/validation.md`; update this skill only when the operational contract changes. |
| `Documentation~/` | Public architecture, integration, lifecycle, Binding, focus/input, optional integration, migration, compatibility, and validation contracts. Register navigable public guidance in `Documentation~/index.md`; release status also touches the root README, changelog, support table, and validation index. |

## Cross-cutting update rules

- Public API, serialized contract, host boundary, lifecycle, or behavior change:
  update the closest design/code/tests plus public documentation and changelog in
  the same candidate.
- Candidate identity, supported profile, gate, evidence schema, sanitizing rule,
  artifact mapping, or cleanup change: update `Tools~/Release`, its tests, and
  validation/release documentation together.
- Base/TMP boundary change: prove Base assemblies and Base Consumer remain free of
  TMP references while the optional Integration and its independent Consumer
  still pass.
- Release history and support claims are post-release facts. Update them after a
  verified GitHub Release, outside the immutable Tag Tree.

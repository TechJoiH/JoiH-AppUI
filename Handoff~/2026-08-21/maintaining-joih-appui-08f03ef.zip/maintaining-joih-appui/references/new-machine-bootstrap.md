# New-machine bootstrap

This mode inventories and reports. It does not install software, sign in, clone,
pull, or edit unless the user separately requests that local action. A missing
capability is `Blocked`, never an invitation to install automatically.

## 1. Establish repository and authentication

Discover commands instead of saving machine paths:

```powershell
$gitCommand = Get-Command git -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
$ghCommand = Get-Command gh -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
```

If either command is missing, report a blocker and stop before dereferencing its
`.Source`. Before any GitHub CLI clone, verify active authentication without
capturing its output:

```powershell
if (-not $gitCommand) { throw 'Blocked: Git is unavailable.' }
if (-not $ghCommand) { throw 'Blocked: GitHub CLI is unavailable.' }
& $ghCommand.Source auth status --active *> $null
if ($LASTEXITCODE -ne 0) { throw 'Blocked: GitHub CLI authentication is unavailable.' }
```

If the checkout is missing, confirm the destination and
official repository identity before using the discovered Git or GitHub CLI. For
the current official repository, an authorized clone can use:

```powershell
& $ghCommand.Source repo clone TechJoiH/JoiH-AppUI $repo
```

GitHub authentication is local machine state. Let the user complete `gh auth
login`; never write auth output, tokens, scopes, credential-store contents, or
remote URLs containing credentials to a report. The environment inspector reports
only active-account facts. Release-state v1 accepts `github.com` provenance;
GitHub Enterprise Server and non-GitHub remotes remain ambiguous and block release
mutation.

## 2. Run the first read-only audit

From the skill root:

```powershell
$environment = & .\scripts\inspect-maintainer-environment.ps1 -RepositoryPath $repo
$environment | ConvertTo-Json -Depth 20
```

Resolve every reported issue before release work. Do not treat `Ready` as proof
that candidate validation passed. `-SkipExternalToolProbes` deliberately returns
`Blocked`; it is useful only for bounded layout diagnostics.

## 3. Select the repository-declared Unity target

Read `package.json`, `Documentation~/validation.md`, and
`Validation~/Unity6000.0Consumer/ProjectSettings/ProjectVersion.txt`. The official
line is the repository's declared target, not the newest installed Editor. Select
the installation whose reported `productVersion` exactly equals the validation
pin. The inspector reports the declarations as `repository.unityLine` and
`repository.validationEditorVersion`, the bounded candidates as
`tools.unity.installations`, and the exact match as `tools.unity.selectedPath` /
`selectedProductVersion`. Keep its discovered path only in command variables or
external run state.

The current repository declares Unity `6000.0` and pins validation to
`6000.0.25f1`. If the exact pin is unavailable, validation is blocked; do not
substitute a newer Unity installation.

## 4. Validate Windows IL2CPP prerequisites

The environment inspector imports the repository-owned
`Tools~/Release/AppUI.ReleaseTools.psm1` and calls its exported
`Test-AppUIBuildEnvironment` contract with the selected exact Editor and pin. Its
`tools.buildEnvironment.status` must be `Ready`. That authoritative gate owns the
Visual Studio 2022 C++ tools, `vcvars64.bat`, `cl.exe`, `link.exe`, `rc.exe`, and
`WindowsSdkDir` checks; the skill inspector does not duplicate a weaker
`vswhere`-only probe. Missing modules, mismatched Editors, and failed or blocked
gate results stay `Blocked`; Mono results cannot replace IL2CPP.

## 5. Detect worktree topology

Review `environment.repository.gitRoot`, `branch`, and `linkedWorktree`, then
confirm with read-only Git facts:

```powershell
& $gitCommand.Source -C $repo status --short --branch
& $gitCommand.Source -C $repo worktree list --porcelain
& $gitCommand.Source -C $repo remote -v
```

Preserve dirty user work. Release work needs a separate clean linked worktree at
an exact candidate Commit; never clean, reset, stash, or overwrite another
worktree to manufacture readiness.

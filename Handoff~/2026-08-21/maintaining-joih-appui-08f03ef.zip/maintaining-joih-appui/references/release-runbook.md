# Release runbook

`Tools~/Release` and `Documentation~/validation.md` are authoritative. Inspect
their current parameters and outputs before every candidate; do not copy an old
asset list, test total, Unity path, or release count:

```powershell
$gitPath = (Get-Command git -CommandType Application -ErrorAction Stop | Select-Object -First 1).Source
$ghCommand = Get-Command gh -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $ghCommand) { throw 'Blocked: GitHub CLI is unavailable.' }
& $ghCommand.Source auth status --active *> $null
if ($LASTEXITCODE -ne 0) { throw 'Blocked: GitHub CLI authentication is unavailable.' }
$ghPath = $ghCommand.Source
$repo = (& $gitPath rev-parse --show-toplevel).Trim()
$tools = Join-Path $repo 'Tools~\Release'
Get-ChildItem -LiteralPath $tools -File
Get-Command (Join-Path $tools 'Invoke-AppUIPreTagValidation.ps1') -Syntax
Get-Command (Join-Path $tools 'Invoke-AppUIGitInstallSmoke.ps1') -Syntax
Get-Command (Join-Path $tools 'New-AppUIReleaseReport.ps1') -Syntax
Get-Command (Join-Path $tools 'New-AppUIReleaseArtifacts.ps1') -Syntax
```

## Release-state contract

Run both skill inspectors first. Release-state v1 binds local HEAD Commit/Tree,
package version, working-tree state, remote `main`, matching annotated Tag, and an
exact GitHub Release query. It accepts `github.com`; GitHub Enterprise Server,
non-GitHub, unavailable, malformed, or timed-out remote state is
`RemoteStateAmbiguous`. A Tag-free candidate is `CandidateUnverified` unless
`-CandidateEvidencePath` names a repository-owned report with `status = Passed`,
a PreTag-compatible mode, and exact current Commit/Tree/version/planned-Tag
identity. Only that evidence can advance it to `CandidateNotPushed` or
`ReadyForTag`.

Existing exact Tags reconcile independently of local candidate evidence.
`tag.identityVerified` proves only that the remote annotated Tag peels to the
source Commit; it is not Tag URL installation-smoke evidence. A GitHub Release is
compatible only when its Tag and canonical URL are exact, it is not draft, and
its prerelease flag matches the package SemVer. `Published` means the exact Tag
and compatible Release were reconciled remotely. It does not prove Commit smoke,
Tag smoke, asset integrity, or uploaded-asset audit; all remain independent gates.

Current AppUI release tools accept strict SemVer including `+build` metadata.
Release-state v1 currently rejects build metadata. This is an inspector limitation,
not repository policy: report the inconsistency and block the release until the
inspector contract is corrected or the chosen version independently changes.

## Proven 18-step flow

1. Use a clean linked worktree; preserve unrelated user work.
2. Resolve exact identity: `$commit = (& $gitPath -C $repo rev-parse HEAD).Trim()` and
   `$tree = (& $gitPath -C $repo rev-parse "$commit`^{tree}").Trim()`. Read `$version`
   from `package.json`; `$tag = "v$version"`.
3. Run the current release-tool suite, then static policy:
   `& "$tools\Tests\Invoke-AppUIReleaseToolsTests.ps1" -TestGroup All`.
4. Within the single Pre-tag orchestration in stage 6, its snapshot sub-gate
   exports the deterministic candidate and binds Commit, Tree, version and
   package-manifest SHA-256.
5. Within that same orchestration, its Consumer-layout sub-gate materializes fresh
   Base and TextMeshPro Consumers with no shared `Library`, generated files, logs
   or builds. The standalone snapshot/Consumer scripts are diagnostic entry points
   only; do not run them as a second release path or substitute their output into
   formal evidence.
6. Run the repository-defined snapshot, Consumer, Binding, EditMode, PlayMode,
   Mono and IL2CPP sub-gates for every supported profile through the current
   orchestrator:

   ```powershell
   & "$tools\Invoke-AppUIPreTagValidation.ps1" -RepositoryPath $repo `
     -SourceCommit $commit -PlannedTag $tag -UnityPath $unityPath -RunRoot $preTagRoot
   ```

7. Verify the report is `Passed`, re-audit the snapshot, and re-resolve HEAD
   Commit/Tree; any drift creates a new candidate and new evidence. Assign
   `$candidateEvidencePath` to the actual Pre-tag report path returned by the
   current orchestrator (inspect its current output contract; do not guess a
   filename), then require the release inspector to report verified evidence:

   ```powershell
   $candidateState = & (Join-Path $skillRoot 'scripts\inspect-release-state.ps1') `
     -RepositoryPath $repo -CandidateEvidencePath $candidateEvidencePath
   if (-not $candidateState.candidateEvidence.verified) {
     throw 'Candidate evidence is missing, malformed, or does not match the current identity.'
   }
   ```
8. Stop for explicit candidate-push authorization. Update remote `main` from the
   exact validated Commit with a non-force explicit refspec; never rely on the
   current local branch name or local `main`:

   ```powershell
   & $gitPath -C $repo push origin "${commit}:refs/heads/main"
   if ($LASTEXITCODE -ne 0) { throw 'Candidate push failed or was rejected.' }
   ```

   Rerun the release-state inspector, passing
   `-CandidateEvidencePath $candidateEvidencePath`, and require both
   `remoteMainCommit == $commit` and `candidatePushed == true` before continuing.
9. In another new Run Root, run the Commit smoke and bind its evidence to the same
   Commit/Tree/version/manifest hash:

   ```powershell
   $commitSmokeRoot = Join-Path $releaseWorkRoot `
     ('joih-appui-smoke-' + [Guid]::NewGuid().ToString('N') + '-commit')
   & "$tools\Invoke-AppUIGitInstallSmoke.ps1" `
     -PackageReference "https://github.com/TechJoiH/JoiH-AppUI.git#$commit" `
     -ExpectedPackageVersion $version -UnityPath $unityPath -RunRoot $commitSmokeRoot `
     -RepositoryPath $repo
   ```

10. Run the current readiness command:

    ```powershell
    & "$tools\Test-AppUIReleaseReadiness.ps1" -RepositoryPath $repo `
      -CandidateCommit $commit -PlannedTag $tag
    ```

    Require remote `main == $commit` and an unused `$tag`. A blocked/ambiguous
    query is not absence.
11. Stop for explicit immutable-Tag authorization. Create one annotated Tag on
    `$commit`, check the native result, re-resolve the local object and peeled
    Commit, and only then push that exact ref once:

    ```powershell
    & $gitPath -C $repo tag -a $tag $commit -m "Joi.H AppUI $version"
    if ($LASTEXITCODE -ne 0) {
      throw 'Tag creation failed or was ambiguous. Stop mutation and follow failure recovery.'
    }

    $tagObjectOutput = @(& $gitPath -C $repo rev-parse --verify "refs/tags/$tag" 2>$null)
    $tagObjectExitCode = $LASTEXITCODE
    $tagObject = if ($tagObjectOutput.Count -eq 1) { ("$($tagObjectOutput[0])").Trim() } else { $null }
    if ($tagObjectExitCode -ne 0 -or $tagObject -notmatch '^[0-9a-f]{40}$') {
      throw 'The new local Tag object could not be resolved unambiguously. Follow failure recovery.'
    }

    $tagObjectTypeOutput = @(& $gitPath -C $repo cat-file -t $tagObject 2>$null)
    $tagObjectTypeExitCode = $LASTEXITCODE
    $tagObjectType = if ($tagObjectTypeOutput.Count -eq 1) { ("$($tagObjectTypeOutput[0])").Trim() } else { $null }
    if ($tagObjectTypeExitCode -ne 0 -or $tagObjectType -cne 'tag') {
      throw 'The new local ref is not one exact annotated Tag object. Follow failure recovery.'
    }

    $peeledCommitOutput = @(& $gitPath -C $repo rev-parse --verify "refs/tags/$tag^{}" 2>$null)
    $peeledCommitExitCode = $LASTEXITCODE
    $peeledCommit = if ($peeledCommitOutput.Count -eq 1) { ("$($peeledCommitOutput[0])").Trim() } else { $null }
    if ($peeledCommitExitCode -ne 0 -or $peeledCommit -cne $commit) {
      throw 'The new local Tag does not peel to the exact authorized candidate. Follow failure recovery.'
    }

    & $gitPath -C $repo push origin "refs/tags/$tag"
    if ($LASTEXITCODE -ne 0) {
      throw 'Tag push failed or was ambiguous. Do not run Tag smoke; reconcile through read-only recovery.'
    }

    $tagState = & (Join-Path $skillRoot 'scripts\inspect-release-state.ps1') `
      -RepositoryPath $repo -CandidateEvidencePath $candidateEvidencePath
    if ($tagState.status -eq 'RemoteStateAmbiguous' -or
        -not $tagState.tag.exists -or -not $tagState.tag.identityVerified) {
      throw 'Remote Tag identity is not proven. Do not run Tag smoke; follow failure recovery.'
    }
    ```

    Every nonzero, malformed, or ambiguous Tag-command result stops this flow and
    routes to read-only reconciliation in `failure-recovery.md`; it never falls
    through automatically to Tag smoke.

12. Create `$tagSmokeRoot` under the same owned parent with a new GUID and the
    `joih-appui-smoke-` prefix, then repeat the step 9 smoke command with the Tag
    URL. Failure makes this version a `Failed Release Attempt`; never move,
    delete, recreate, or reuse the Tag.
13. Create a new external `$stageRoot`. Its exact dual-profile source contract is:

    ```text
    release-report.json                         <- Formal report generated below
    package-manifest.json                       <- Pre-tag evidence root
    base/{editmode.xml,playmode.xml,binding-validation.json,
          build-windowsmono.json,build-windowsil2cpp.json} <- Pre-tag Base evidence
    textmeshpro/{editmode.xml,playmode.xml,binding-validation.json,
          build-windowsmono.json,build-windowsil2cpp.json,
          textmeshpro-integration.json}          <- Pre-tag TMP evidence
    commit-git-install-smoke.json                <- Commit smoke evidence root
    tag-git-install-smoke.json                   <- Tag smoke evidence root
    logs.zip                                     <- copy of Pre-tag evidence/appui-$tag-logs.zip
    ```

    Copy only those named inputs with `Copy-Item -LiteralPath`; preserve the two
    profile subdirectories. Set `$identityPath` to Pre-tag
    `evidence/candidate-identity.json`, `$preTagEvidenceRoot` to Pre-tag `evidence`,
    and the smoke paths to their separate Run Root `evidence` files. Then generate
    the Formal report directly at `$stageRoot/release-report.json`:

    ```powershell
    & "$tools\New-AppUIReleaseReport.ps1" -IdentityPath $identityPath `
      -EvidenceRoot $preTagEvidenceRoot `
      -OutputPath (Join-Path $stageRoot 'release-report.json') `
      -ExpectedSourceCommit $commit -ExpectedSourceTree $tree `
      -ExpectedPackageVersion $version -PlannedTag $tag -Mode Formal `
      -ResolvedTag $tag -RepositoryPath $repo `
      -CommitSmokePath $commitSmokePath -TagSmokePath $tagSmokePath
    ```
    Require every identity field and gate to pass before staging artifacts.
14. Confirm `$stageRoot` contains the exact source contract above, then run the
    current artifact function with distinct redaction boundaries:

    ```powershell
    Import-Module (Join-Path $tools 'AppUI.ReleaseTools.psm1') -Force
    $userProfilePath = [Environment]::GetFolderPath([Environment+SpecialFolder]::UserProfile)
    $preTagBaseConsumerRoot = Join-Path $preTagRoot 'consumer-base'
    $bundle = New-AppUIReleaseArtifacts -SourceDirectory $stageRoot `
      -OutputDirectory $artifactRoot -Version $version -RepositoryPath $repo `
      -ConsumerPath $preTagBaseConsumerRoot -UserProfilePath $userProfilePath `
      -ValidationRootPath $preTagRoot
    ```

    `ConsumerPath` is the specific Base Consumer child and maps to `<CONSUMER>`;
    `ValidationRootPath` is its parent Run Root and maps all remaining Base/TMP
    validation paths to `<VALIDATION_ROOT>`. Never pass the same path for both:
    replacement order would consume it as `<CONSUMER>` first.

    Require its exact artifact count and SHA-256 map. The tool must reject secrets
    (`ghp_`, `github_pat_`, authorization headers, private keys) and local absolute
    paths; do not weaken sanitizing or hand-edit evidence to pass.
15. Stop for explicit GitHub Release authorization. Call `gh release create` once
    with the verified Tag, approved stable/pre-release flags, notes file, and only
    `$artifactRoot` files. If its result is uncertain, do not retry; reconcile.
16. Query the exact Release read-only. Verify URL, Tag, draft/pre-release flags,
    asset count, unique names, `uploaded` state, size, and each remote
    `sha256:` digest against `$bundle.Hashes`. If complete digests are unavailable,
    download to a fresh audit directory and hash every asset; otherwise block.
17. After the Release is accessible, update and test `README.md`, `CHANGELOG.md`,
    `Documentation~/supported-unity-versions.md`, and
    `Documentation~/validation.md` in a docs-only Commit outside the Tag Tree.
    Obtain separate authorization before pushing it; reprove the Tag did not move.
18. The existing cleanup helper owns only Pre-tag `consumer-base` and
    `consumer-textmeshpro`; it does not accept a Git-smoke `consumer` leaf. Before
    deleting smoke data, copy its evidence into `$stageRoot` and preserve the
    verified artifacts/hashes elsewhere. Create every smoke Run Root as a unique
    direct child of an operator-owned `$releaseWorkRoot`, record its exact path,
    then remove only a recorded root after these checks:

    ```powershell
    foreach ($preserved in @(
      (Join-Path $stageRoot 'commit-git-install-smoke.json'),
      (Join-Path $stageRoot 'tag-git-install-smoke.json'))) {
      if (-not (Test-Path -LiteralPath $preserved -PathType Leaf)) {
        throw "Smoke evidence was not preserved: $preserved"
      }
    }
    $ownedParent = [IO.Path]::GetFullPath($releaseWorkRoot).TrimEnd(
      [IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
    foreach ($recordedRoot in @($commitSmokeRoot, $tagSmokeRoot)) {
      $target = [IO.Path]::GetFullPath($recordedRoot).TrimEnd(
        [IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
      $prefix = $ownedParent + [IO.Path]::DirectorySeparatorChar
      if (-not $target.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Cleanup target escaped the owned parent: $target"
      }
      if ((Split-Path $target -Parent) -ne $ownedParent -or
          -not (Split-Path $target -Leaf).StartsWith('joih-appui-smoke-', [StringComparison]::Ordinal)) {
        throw "Cleanup target is not a recorded unique smoke Run Root: $target"
      }
      Remove-Item -LiteralPath $target -Recurse -Force
      if (Test-Path -LiteralPath $target) { throw "Cleanup did not remove: $target" }
    }
    ```

    Preserve reports, sanitized artifacts, hashes, failure evidence, unrelated
    worktrees, and the immutable Tag.

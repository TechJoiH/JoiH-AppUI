# Development workflow

## 1. Reconcile before editing

Run both skill inspectors, then read:

- the closest `Documentation~/` architecture or workflow document;
- the affected Runtime, Editor, Integration, Sample, or release-tool code;
- its direct tests and current public contract text.

Inspect `git status --short --branch`, `git diff`, and `git worktree list
--porcelain`. Preserve unrelated changes. Do not reset, clean, stash, checkout, or
rewrite user work. If isolation is required, use a clean linked worktree at an
explicit base Commit.

## 2. Define the smallest contract change

State the affected responsibility, public/serialized interface, lifecycle and
data flow, files, compatibility impact, and verification. Keep AppUI Core neutral:
the package exposes Operation, Asset Provider, and Execution Context contracts;
it does not select UniTask, Task, Awaitable, Coroutine, Resources, Addressables,
TextMeshPro, or a project framework as the default implementation.

## 3. Implement with targeted evidence

Change the owning area from the repository map and update its direct tests first.
Use the smallest relevant Unity test assemblies or editor workflow before broad
validation. For repository release contracts, use the current test entry point:

```powershell
& (Join-Path $repo 'Tools~\Release\Tests\Invoke-AppUIReleaseToolsTests.ps1') -TestGroup Policy
```

Select `Snapshot`, `Consumer`, `Policy`, `Orchestration`, or `Docs` to match the
change; run `All` for release-facing or cross-cutting changes. Treat package tests
as development evidence only.

## 4. Keep Base and TextMeshPro isolated

Base Runtime, Base Editor, package dependencies, Basic Sample, and Base Consumer
must compile without `Unity.TextMeshPro` or `JOIH_APPUI_TMP`. Optional TMP code
stays in `Integrations/TextMeshPro`, its Sample/tests, and the separately
materialized TextMeshPro Consumer. Run Consumer/Policy/Orchestration coverage when
this boundary changes. Do not make Base pass by installing or selecting a
consumer implementation.

## 5. Synchronize contracts and verify

Update `CHANGELOG.md`, the closest public guide, migrations, Sample README, and
support/validation docs when their claims change. New public docs belong in
`Documentation~/index.md`. Run targeted tests, then risk-matched broader tests,
`git diff --check`, and a focused diff review. Candidate/release work continues in
the release runbook; no development result authorizes push, Tag, or Release.

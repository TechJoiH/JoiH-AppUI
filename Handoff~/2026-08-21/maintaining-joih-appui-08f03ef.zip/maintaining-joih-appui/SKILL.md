---
name: maintaining-joih-appui
description: Use when maintaining Joi.H AppUI across computers or resuming its development, validation, release, or failed-release recovery work.
---

# Maintaining Joi.H AppUI

## Start Here

Set `$repo` to the current AppUI repository root and `$skillRoot` to the directory
containing this `SKILL.md`. Before changing repository or remote state, run both
read-only inspectors and report their status, evidence, reason codes, and next safe
action:

```powershell
$environment = & (Join-Path $skillRoot 'scripts\inspect-maintainer-environment.ps1') -RepositoryPath $repo
$release = & (Join-Path $skillRoot 'scripts\inspect-release-state.ps1') -RepositoryPath $repo
$environment | ConvertTo-Json -Depth 20
$release | ConvertTo-Json -Depth 20
```

After Pre-tag validation produces its repository-owned report, rerun release
inspection with `-CandidateEvidencePath $candidateEvidencePath`. A Tag-free
candidate remains `CandidateUnverified` until that report is `Passed`, uses a
PreTag-compatible mode, and matches the current Commit, Tree, package version,
and planned Tag.

Inspector output never authorizes a mutation. Local edits require the user's
request; candidate push, Tag creation/push, GitHub Release, and post-release push
require explicit authorization at their checkpoints.

## Load Only The Needed Reference

- New computer or missing tools: read [new-machine-bootstrap.md](references/new-machine-bootstrap.md).
- Repository structure or ownership question: read [repository-map.md](references/repository-map.md).
- Update, refactor, tests or docs: read [development-workflow.md](references/development-workflow.md).
- Candidate validation or formal publication: read [release-runbook.md](references/release-runbook.md).
- Existing Tag, interrupted command or ambiguous remote: read [failure-recovery.md](references/failure-recovery.md).

| Inspector status | Load next |
| --- | --- |
| Environment `Blocked` / release `EnvironmentBlocked` | Bootstrap |
| `WorkingTreeDirty` | Development workflow |
| `CandidateUnverified` | Release runbook stages 3-7; generate candidate evidence |
| `CandidateNotPushed` / `ReadyForTag` | Release runbook; use the already verified candidate evidence |
| `TagExistsUnverified` / `FailedReleaseAttempt` / `RemoteStateAmbiguous` | Failure recovery |
| `Published` | Release runbook's independent smoke/evidence audit and post-release steps |

## Non-Negotiable Invariants

- One clean candidate Commit/Tree owns all release evidence.
- External Consumers prove installation; package self-tests do not replace them.
- Commit URL smoke precedes Tag creation; Tag URL smoke follows it.
- `Published` reconciles remote Tag/Release identity and flags; it does not prove
  either installation-smoke gate.
- Never move, delete or reuse an immutable Tag.
- Never blind-retry a GitHub mutation with an ambiguous result.
- Keep credentials and machine paths out of files and release artifacts.
